<?php
require 'conexao.php';
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$stmt = $pdo->query("SELECT nome, email, tipo FROM usuarios");
echo "Usuários cadastrados: <br>";
while ($usuario = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "Nome: " . htmlspecialchars($usuario['nome']) . " | E-mail: " . htmlspecialchars($usuario['email']) . " | Tipo: " . htmlspecialchars($usuario['tipo']) . "<br>";
 }
?>
<a href="dashboard_funcionario.php">Voltar para perfil</a>