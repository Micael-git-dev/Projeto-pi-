<?php
require 'conexao.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

// Processamento do formulário de cadastro de produtos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $preco = $_POST['preco'];
    $quantidade = $_POST['quantidade'];  // Captura a quantidade informada

    $stmt = $pdo->prepare("INSERT INTO produtos (nome, preco, quantidade) VALUES (:nome, :preco, :quantidade)");
    if ($stmt->execute([':nome' => $nome, ':preco' => $preco, ':quantidade' => $quantidade])) {
        echo "Produto cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar produto!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro de produto</title>
    </head>
    <body>
        <h2>Cadastro de Produtos</h2>
        <form method="POST">
            <label for="nome-produto">Nome do Produto: </label>
            <input type="text" name="nome" id="nome-produto" required><br><br>
            <!--DIVISÃO-->
            <label for="preco-produto">Preço: </label>
            <input type="number" name="preco" step="0.01" id="preco-produto" required><br><br>
            <!--DIVISÃO-->
            <label for="quantidade">Quantidade em Estoque: </label>
            <input type="number" name="quantidade" min="0" id="quantidade" required><br><br> <!-- Campo de quantidade -->
            <!--DIVISÃO-->
            <button type="submit">Cadastrar Produto</button>
        </form>
        <hr>
        <h2>Produtos Cadastrados</h2>

        <?php
            // Listagem de produtos cadastrados
            $stmt = $pdo->query("SELECT * FROM produtos");
            while ($produto = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo htmlspecialchars($produto['nome']) . " - R$" . number_format($produto['preco'], 2, ',', '.') . " - Estoque: " . $produto['quantidade'] . "<br>";
            }
        ?>
    </body>
</html>

<p><a href="dashboard_funcionario.php">Voltar para o perfil</a></p>